#include "MathLib/Scene/SceneObject.h"

// The Inferior SceneObject
namespace MathLib
{
    // The Superior Scene Object
    SceneObject::SceneObject()
        : m_localTransform{ Mat3::MakeIdentity() }, m_parent{ nullptr }
    {
    }

    SceneObject::~SceneObject()
    {
        // Delete all children
        while (!m_children.empty())
        {
            delete m_children.front();
        }

        // Remove this object from its parent's children list
        if (m_parent != nullptr)
        {
            m_parent->RemoveChild(this);
            m_parent->ApplyListChanges();
        }
    }

    void SceneObject::Tick(float dt)
    {
        // Run this object's tick logic first
        OnTick(dt);

        // Apply any pending parent-child relationship changes
        ApplyListChanges();

        // Update all children
        for (auto* child : m_children)
        {
            child->Tick(dt);
        }
    }

    void SceneObject::Render()
    {
        // Run this object's render logic first
        OnRender();

        // Render all children
        for (auto* child : m_children)
        {
            child->Render();
        }
    }

    void SceneObject::SetParent(SceneObject* parent)
    {
        // Are we un-parenting this object?
        if (parent == nullptr)
        {
            // Do we actually have a parent?
            if (m_parent != nullptr)
            {
                m_parent->RemoveChild(this);
            }
        }
        else
        {
            // Set new parent (this will handle removing from old parent)
            parent->AddChild(this);
        }
    }

    SceneObject* SceneObject::GetParent() const
    {
        return m_parent;
    }

    void SceneObject::ApplyTransform(const Mat3& transform)
    {
        m_localTransform = transform * m_localTransform;
    }

    void SceneObject::SetLocalTransform(const Mat3& transform)
    {
        m_localTransform = transform;
    }

    const Mat3& SceneObject::GetLocalTransform() const
    {
        return m_localTransform;
    }

    Mat3 SceneObject::GetGlobalTransform() const
    {
        if (m_parent)
        {
            // Combine with parent's transform
            return m_parent->GetGlobalTransform() * m_localTransform;
        }

        // No parent, local is global
        return m_localTransform;
    }

    Vec2 SceneObject::GetPosition() const
    {
        const Mat3 globalTransform = GetGlobalTransform();
        return { globalTransform.m7, globalTransform.m8 };
    }

    Vec2 SceneObject::GetForward() const
    {
        // Calculate forward vector based on rotation
        float rotation = GetRotation(); // Already in radians

        Vec2 forward(-sinf(rotation), cosf(rotation));
        forward.Normalise();

        return forward;
    }

    float SceneObject::GetRotation() const
    {
        const Mat3 globalTransform = GetGlobalTransform();
        return atan2f(globalTransform.m2, globalTransform.m1);
    }

    void SceneObject::RotateRadians(float radians)
    {
        ApplyTransform(Mat3::MakeZRotation(radians));
    }

    void SceneObject::OnTick(float dt) {}

    void SceneObject::OnRender() {}

    void SceneObject::AddChild(SceneObject* child)
    {
        m_childListChanges.emplace_back([child, this]
            {
                // Remove child from its current parent first
                if (child->m_parent != nullptr)
                {
                    child->m_parent->RemoveChild(child);
                    child->m_parent->ApplyListChanges();
                }

                // Set this as the new parent
                child->m_parent = this;

                m_children.emplace_back(child);
            });
    }

    void SceneObject::RemoveChild(const SceneObject* child)
    {
        // Use deferred execution to prevent iterator invalidation
        m_childListChanges.emplace_back([child, this]()
            {
                if (const auto it = std::ranges::find(m_children, child); it != m_children.end())
                {
                    // Only clear parent pointer if this object is actually the parent
                    if ((*it)->m_parent == this)
                    {
                        (*it)->m_parent = nullptr;
                    }
                    m_children.erase(it);
                }
            });
    }

    void SceneObject::ApplyListChanges()
    {
        for (auto& change : m_childListChanges)
        {
            change();
        }

        m_childListChanges.clear();
    }
}