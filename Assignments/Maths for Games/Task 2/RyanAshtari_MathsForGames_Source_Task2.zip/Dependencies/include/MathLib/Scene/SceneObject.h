#pragma once

#include <functional>
#include <vector>

#include "MathLib/Types/Mat3.h"
#include "MathLib/Types/Vec2.h"

using MathLib::Mat3;
using MathLib::Vec2;

// The Inferior SceneObject
namespace MathLib
{
    class SceneObject
    {
    public:
        SceneObject();
        virtual ~SceneObject();

    public:
        // Main update/render methods - DON'T override these in derived classes
        void Tick(float dt);
        void Render();

        // Parent-child relationship management
        void SetParent(SceneObject* parent);
        SceneObject* GetParent() const;

        // Transform methods
        void ApplyTransform(const Mat3& transform);
        void SetLocalTransform(const Mat3& transform);

        const Mat3& GetLocalTransform() const;
        Mat3 GetGlobalTransform() const;

        // Utility methods for getting common transform values
        Vec2 GetPosition() const;
        Vec2 GetForward() const;
        float GetRotation() const;

        void RotateRadians(float radians);

    protected:
        // Virtual methods for derived classes to override
        virtual void OnTick(float dt);
        virtual void OnRender();

        // Transform data
        Mat3 m_localTransform;

    private:
        // Parent-child relationship data
        SceneObject* m_parent;
        std::vector<SceneObject*> m_children;

        // Deferred list changes system to prevent iterator invalidation
        std::vector<std::function<void()>> m_childListChanges;

        // Private methods for managing child relationships
        void AddChild(SceneObject* child);
        void RemoveChild(const SceneObject* child);
        void ApplyListChanges();
    };
}